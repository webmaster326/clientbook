import { json } from "@remix-run/node";
//import prisma db
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
import { cors } from 'remix-utils/cors';


// get request: accept request with request: customerId, shop, productId.
// read database and return wishlist items for that customer.
export async function loader({ request }) {
  const url = new URL(request.url);
  const first_name = url.searchParams.get("first_name");
  const last_name = url.searchParams.get("last_name");
  const email_address = url.searchParams.get("email_address");


  if(!first_name || !last_name || !email_address) {
    return json({
      message: "Missing data. Required data: first_name, email_address, last_name",
      method: "GET"
    });
  }


  const response = json({
    ok: true,
    message: "Success",
  });

  return cors(request, response);

}


// Expexted data comes from post request. If
// first_name, productID, shop
export async function action({ request }) {
  let data = await request.formData();
  data = Object.fromEntries(data);

  console.log(data);
  const firstName = data.first_name;
  const lastName = data.last_name;
  const emailAddress = data.email_address;
  const countryCode = data.country_code;
  const phoneNumber = data.phone_number;
  const designOptions = data.design_options;
  const metalOptions = data.metal_options;
  const preferredPriceRange = data.preferred_price_range;
  const preferredContactMethod = data.preferred_contact_method;
  const availabilityOption = data.availability_option;
  const designNotes = data.design_notes;
  const fileUpload = 'hello'; // Assuming this is the file path or URL

  const _action = data._action;

  if (!firstName || !lastName || !emailAddress || !_action) {
    return json({
      message: "Missing data. Required data: first_name, last_name, email_address, _action",
      method: _action
    });
  }

  let response;

  switch (_action) {
    case "CREATE":
      // Insert new data into the JewelryDesignForm table
      try {
        const newDesign = await db.jewelryDesignForm.create({
          data: {
            firstName,
            lastName,
            emailAddress,
            countryCode,
            phoneNumber,
            designOptions,
            metalOptions,
            preferredPriceRange,
            preferredContactMethod,
            availabilityOption,
            designNotes,
            fileUpload,
          },
        });

        response = json({
          message: "Design submitted successfully",
          method: _action,
          design: newDesign
        });
      } catch (error) {
        console.error(error);
        response = json({
          message: "Error saving design",
          method: _action,
          error: error.message
        }, { status: 500 });
      }

      return cors(request, response);

    case "PATCH":
      // Handle PATCH request logic here (e.g., update existing design)
      return json({ message: "Success", method: "PATCH" });

    case "DELETE":
      // Handle DELETE request logic here (e.g., remove a design)
      return json({ message: "Success", method: "DELETE" });

    default:
      return new Response("Method Not Allowed", { status: 405 });
  }
}