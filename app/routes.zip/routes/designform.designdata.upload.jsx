// app/routes/api/upload.jsx
import { json } from "@remix-run/node";
import fs from 'fs';
import path from 'path';
import { Readable, pipeline } from 'stream';
import { promisify } from 'util';

const pipelineAsync = promisify(pipeline);

export const action = async ({ request }) => {
  const formData = await request.formData();
  const file = formData.get('file');

  if (file && file instanceof File) {
    // Create a path to save the uploaded file
    const uploadDir = path.join(process.cwd(), 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    const filePath = path.join(uploadDir, file.name);
    
    try {
      // Use a stream to handle the file upload
      const fileStream = fs.createWriteStream(filePath);
      
      // Create a readable stream from the file buffer
      const buffer = Buffer.from(await file.arrayBuffer());
      const readableStream = Readable.from(buffer);

      await pipelineAsync(
        readableStream,
        fileStream
      );

      console.log('Received file:', file.name);
      return json({ success: true, message: 'File uploaded successfully' });
    } catch (error) {
      console.error('Error writing file:', error);
      return json({ success: false, message: 'File upload failed' }, { status: 500 });
    }
  }

  return json({ success: false, message: 'No file uploaded' }, { status: 400 });
};
